package bean;

public class TransferBean {

}
